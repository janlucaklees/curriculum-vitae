import{a as t}from"../chunks/entry.JJfxKK0s.js";export{t as start};
