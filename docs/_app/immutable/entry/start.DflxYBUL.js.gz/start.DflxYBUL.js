import{a as t}from"../chunks/entry.DrOQU74U.js";export{t as start};
